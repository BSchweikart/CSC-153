﻿namespace M4HW2_Schweikart
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rollButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.dieImageList = new System.Windows.Forms.ImageList(this.components);
            this.die1PictureBox = new System.Windows.Forms.PictureBox();
            this.die2PictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // rollButton
            // 
            this.rollButton.Location = new System.Drawing.Point(85, 190);
            this.rollButton.Name = "rollButton";
            this.rollButton.Size = new System.Drawing.Size(75, 36);
            this.rollButton.TabIndex = 0;
            this.rollButton.Text = "Roll";
            this.rollButton.UseVisualStyleBackColor = true;
            this.rollButton.Click += new System.EventHandler(this.rollButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(244, 190);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 36);
            this.exitButton.TabIndex = 1;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // dieImageList
            // 
            this.dieImageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("dieImageList.ImageStream")));
            this.dieImageList.TransparentColor = System.Drawing.Color.Transparent;
            this.dieImageList.Images.SetKeyName(0, "Die1.bmp");
            this.dieImageList.Images.SetKeyName(1, "Die2.bmp");
            this.dieImageList.Images.SetKeyName(2, "Die3.bmp");
            this.dieImageList.Images.SetKeyName(3, "Die4.bmp");
            this.dieImageList.Images.SetKeyName(4, "Die5.bmp");
            this.dieImageList.Images.SetKeyName(5, "Die6.bmp");
            // 
            // die1PictureBox
            // 
            this.die1PictureBox.InitialImage = null;
            this.die1PictureBox.Location = new System.Drawing.Point(56, 38);
            this.die1PictureBox.Name = "die1PictureBox";
            this.die1PictureBox.Size = new System.Drawing.Size(104, 104);
            this.die1PictureBox.TabIndex = 2;
            this.die1PictureBox.TabStop = false;
            // 
            // die2PictureBox
            // 
            this.die2PictureBox.Location = new System.Drawing.Point(244, 38);
            this.die2PictureBox.Name = "die2PictureBox";
            this.die2PictureBox.Size = new System.Drawing.Size(104, 104);
            this.die2PictureBox.TabIndex = 3;
            this.die2PictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 321);
            this.Controls.Add(this.die2PictureBox);
            this.Controls.Add(this.die1PictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollButton);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.die1PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.die2PictureBox)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button rollButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ImageList dieImageList;
        private System.Windows.Forms.PictureBox die1PictureBox;
        private System.Windows.Forms.PictureBox die2PictureBox;
    }
}

