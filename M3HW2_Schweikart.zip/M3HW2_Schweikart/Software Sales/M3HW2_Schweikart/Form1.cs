﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 03/02/2018
* CSC 153
* Brian Schweikart
* Software Sales
*/

namespace M3HW2_Schweikart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Set sale constant.
                const decimal Sale = 99;
                 
                // Set local variables.
                decimal quantity;
                decimal discountTwenty = 0.2m;
                decimal discountThirty = 0.3m;
                decimal discountFourty = 0.4m;
                decimal discountFifty = 0.5m;

                // Get quantity. 
                quantity = decimal.Parse(quantityTextBox.Text);

                // Calculate subtotal.
                decimal subtotal = quantity * Sale;

                // Calculate discount.
                decimal twenty = subtotal * discountTwenty;
                decimal thirty = subtotal * discountThirty;
                decimal fourty = subtotal * discountFourty;
                decimal fifty = subtotal * discountFifty;

                // Calculate total price w/discount.
                decimal totalTwenty = subtotal - twenty;
                decimal totalThirty = subtotal - thirty;
                decimal totalFourty = subtotal - fourty;
                decimal totalFifty = subtotal - fifty;


                // Set quantiy count.
                if (quantity <= 9)
                {
                    // Display subtotal.
                    subTotalLabel.Text = subtotal.ToString("c");
                    
                    // Display discount.
                    discountLabel.Text = ("Quantity not met");

                    // Display Total w/discount.
                    totalLabel.Text = subTotalLabel.Text;
                }

                if (quantity >= 10 && quantity <= 19)
                {

                    subTotalLabel.Text = subtotal.ToString("c");
                    discountLabel.Text = twenty.ToString("c");
                    totalLabel.Text = totalTwenty.ToString("c");
                }

                if (quantity >= 20 && quantity <= 49)
                {

                    subTotalLabel.Text = subtotal.ToString("c");
                    discountLabel.Text = thirty.ToString("c");
                    totalLabel.Text = totalThirty.ToString("c");
                }

                if (quantity >= 50 && quantity <= 99)
                {

                    subTotalLabel.Text = subtotal.ToString("c");
                    discountLabel.Text = fourty.ToString("c");
                    totalLabel.Text = totalFourty.ToString("c");
                }

                if (quantity >= 100)
                {

                    subTotalLabel.Text = subtotal.ToString("c");
                    discountLabel.Text = fifty.ToString("c");
                    totalLabel.Text = totalFifty.ToString("c");
                }

            }
            catch
            {
                // Display error message
                MessageBox.Show("Please enter a number");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the the input output fields
            quantityTextBox.Text = "";
            subTotalLabel.Text = "";
            discountLabel.Text = "";
            totalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
