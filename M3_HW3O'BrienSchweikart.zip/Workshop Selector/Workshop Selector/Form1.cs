﻿/**
* 03/03/2018
* CSC 153
* Anthony O'Brien and Brian Schweikart
* Calculates costs of lodging, registration and total for workshops in different locations.
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Workshop_Selector
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Variables
        int registration;
        int lodging;
        int days;

        private void calculateButton_Click(object sender, EventArgs e)
        {
            if (workshopListBox.SelectedIndex != -1)
            {
                switch (workshopListBox.SelectedIndex)
                {
                    case 0:
                        registration = 1000;
                        days = 3;
                        break;
                    case 1:
                        registration = 800;
                        days = 3;
                        break;
                    case 2:
                        registration = 1500;
                        days = 3;
                        break;
                    case 3:
                        registration = 1300;
                        days = 5;
                        break;
                    case 4:
                        registration = 500;
                        days = 1;
                        break;
                }
            }
            else
            {
                MessageBox.Show("No workshop was selected");
            }
            if (locationListBox.SelectedIndex != -1)
            {
                switch (locationListBox.SelectedIndex)
                {
                    case 0:
                        lodging = 150;
                        break;
                    case 1:
                        lodging = 225;
                        break;
                    case 2:
                        lodging = 175;
                        break;
                    case 3:
                        lodging = 300;
                        break;
                    case 4:
                        lodging = 175;
                        break;
                    case 5:
                        lodging = 150;
                        break;
                }
            }
            else
            {
                MessageBox.Show("No location was selected");
            }
            registrationTextBox.Text = (registration).ToString("c");
            lodgingTextBox.Text = (lodging * days).ToString("c");
            totalTextBox.Text = (registration + (lodging * days)).ToString("c");

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
