﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* Date
* CSC 153
* Brian Schweikart
* Name Formatter
*/

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void formatButton_Click(object sender, EventArgs e)
        {
            // sting information
            string firstName;
            string middleName;
            string lastName;
            string title;

            // String Values
            firstName = firstNameTextBox.Text;
            middleName = middleNameTextBox.Text;
            lastName = lastNameTextBox.Text;
            title = titleComboBox.Text;

            // Output into a list box
            nameOutBox.Items.Add(title + " " + firstName + " " + middleName + " " + lastName); //
            nameOutBox.Items.Add(firstName + " " + middleName + " " + lastName);
            nameOutBox.Items.Add(firstName + " " + lastName);
            nameOutBox.Items.Add(lastName + ", " + firstName + " " + middleName + ", " + title);
            nameOutBox.Items.Add(lastName + ", " + firstName + " " + middleName);
            nameOutBox.Items.Add(lastName + ", " + firstName);
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the input
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            titleComboBox.Text = "";
            nameOutBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }
    }
}