﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 02/15/2018
* CSC 153
* Brian Schweikart
* Sentence Builder
*/

namespace Sentence_Builder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /**
         * Take each buttion click from the user
         * save as a string to output in label
         */
        private void aUpperButton_Click(object sender, EventArgs e)
        {
            string output;
            output = aUpperButton.Text;
            sentenceLabel.Text += output;
        }

        private void aLowerButton_Click(object sender, EventArgs e)
        {
            string output;
            output = aLowerButton.Text;
            sentenceLabel.Text += output;
        }

        private void anUpperButton_Click(object sender, EventArgs e)
        {
            string output;
            output = anUpperButton.Text;
            sentenceLabel.Text += output;
        }

        private void anLowerButton_Click(object sender, EventArgs e)
        {
            string output;
            output = anLowerButton.Text;
            sentenceLabel.Text += output;
        }

        private void theUpperButton_Click(object sender, EventArgs e)
        {
            string output;
            output = theUpperButton.Text;
            sentenceLabel.Text += output;
        }

        private void theLowerButton_Click(object sender, EventArgs e)
        {
            string output;
            output = theLowerButton.Text;
            sentenceLabel.Text += output;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            string output;
            output = manButton.Text;
            sentenceLabel.Text += output;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            string output;
            output = womanButton.Text;
            sentenceLabel.Text += output;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            string output;
            output = dogButton.Text;
            sentenceLabel.Text += output;
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            string output;
            output = catButton.Text;
            sentenceLabel.Text += output;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            string output;
            output = carButton.Text;
            sentenceLabel.Text += output;
        }

        private void bicyleButton_Click(object sender, EventArgs e)
        {
            string output;
            output = bicyleButton.Text;
            sentenceLabel.Text += output;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            string output;
            output = beautifulButton.Text;
            sentenceLabel.Text += output;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            string output;
            output = bigButton.Text;
            sentenceLabel.Text += output;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            string output;
            output = smallButton.Text;
            sentenceLabel.Text += output;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            string output;
            output = strangeButton.Text;
            sentenceLabel.Text += output;
        }

        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            string output;
            output = lookedAtButton.Text;
            sentenceLabel.Text += output;
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            string output;
            output = rodeButton.Text;
            sentenceLabel.Text += output;
        }

        private void spokeToButton_Click(object sender, EventArgs e)
        {
            string output;
            output = spokeToButton.Text;
            sentenceLabel.Text += output;
        }

        private void laughedAtButton_Click(object sender, EventArgs e)
        {
            string output;
            output = laughedAtButton.Text;
            sentenceLabel.Text += output;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            string output;
            output = droveButton.Text;
            sentenceLabel.Text += output;
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            string output;
            output = spaceButton.Text = " ";
            sentenceLabel.Text += output;
        }

        private void peiodButton_Click(object sender, EventArgs e)
        {
            string output;
            output = peiodButton.Text;
            sentenceLabel.Text += output;
        }

        private void exoButton_Click(object sender, EventArgs e)
        {
            string output;
            output = exoButton.Text;
            sentenceLabel.Text += output;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the output label
            sentenceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

    }
}
