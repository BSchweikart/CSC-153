﻿namespace Sentence_Builder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.aUpperButton = new System.Windows.Forms.Button();
            this.aLowerButton = new System.Windows.Forms.Button();
            this.anUpperButton = new System.Windows.Forms.Button();
            this.anLowerButton = new System.Windows.Forms.Button();
            this.theUpperButton = new System.Windows.Forms.Button();
            this.theLowerButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicyleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.lookedAtButton = new System.Windows.Forms.Button();
            this.spokeToButton = new System.Windows.Forms.Button();
            this.laughedAtButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.exoButton = new System.Windows.Forms.Button();
            this.peiodButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // aUpperButton
            // 
            this.aUpperButton.Location = new System.Drawing.Point(72, 18);
            this.aUpperButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.aUpperButton.Name = "aUpperButton";
            this.aUpperButton.Size = new System.Drawing.Size(112, 35);
            this.aUpperButton.TabIndex = 0;
            this.aUpperButton.Text = "A";
            this.aUpperButton.UseVisualStyleBackColor = true;
            this.aUpperButton.Click += new System.EventHandler(this.aUpperButton_Click);
            // 
            // aLowerButton
            // 
            this.aLowerButton.Location = new System.Drawing.Point(219, 18);
            this.aLowerButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.aLowerButton.Name = "aLowerButton";
            this.aLowerButton.Size = new System.Drawing.Size(112, 35);
            this.aLowerButton.TabIndex = 1;
            this.aLowerButton.Text = "a";
            this.aLowerButton.UseVisualStyleBackColor = true;
            this.aLowerButton.Click += new System.EventHandler(this.aLowerButton_Click);
            // 
            // anUpperButton
            // 
            this.anUpperButton.Location = new System.Drawing.Point(358, 18);
            this.anUpperButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.anUpperButton.Name = "anUpperButton";
            this.anUpperButton.Size = new System.Drawing.Size(112, 35);
            this.anUpperButton.TabIndex = 2;
            this.anUpperButton.Text = "An";
            this.anUpperButton.UseVisualStyleBackColor = true;
            this.anUpperButton.Click += new System.EventHandler(this.anUpperButton_Click);
            // 
            // anLowerButton
            // 
            this.anLowerButton.Location = new System.Drawing.Point(494, 18);
            this.anLowerButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.anLowerButton.Name = "anLowerButton";
            this.anLowerButton.Size = new System.Drawing.Size(112, 35);
            this.anLowerButton.TabIndex = 3;
            this.anLowerButton.Text = "an";
            this.anLowerButton.UseVisualStyleBackColor = true;
            this.anLowerButton.Click += new System.EventHandler(this.anLowerButton_Click);
            // 
            // theUpperButton
            // 
            this.theUpperButton.Location = new System.Drawing.Point(624, 18);
            this.theUpperButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.theUpperButton.Name = "theUpperButton";
            this.theUpperButton.Size = new System.Drawing.Size(112, 35);
            this.theUpperButton.TabIndex = 4;
            this.theUpperButton.Text = "The";
            this.theUpperButton.UseVisualStyleBackColor = true;
            this.theUpperButton.Click += new System.EventHandler(this.theUpperButton_Click);
            // 
            // theLowerButton
            // 
            this.theLowerButton.Location = new System.Drawing.Point(753, 18);
            this.theLowerButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.theLowerButton.Name = "theLowerButton";
            this.theLowerButton.Size = new System.Drawing.Size(112, 35);
            this.theLowerButton.TabIndex = 5;
            this.theLowerButton.Text = "the";
            this.theLowerButton.UseVisualStyleBackColor = true;
            this.theLowerButton.Click += new System.EventHandler(this.theLowerButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(18, 98);
            this.manButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(112, 35);
            this.manButton.TabIndex = 6;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(200, 98);
            this.womanButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(112, 35);
            this.womanButton.TabIndex = 7;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(358, 98);
            this.dogButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(112, 35);
            this.dogButton.TabIndex = 8;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(521, 98);
            this.catButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(112, 35);
            this.catButton.TabIndex = 9;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(673, 98);
            this.carButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(112, 35);
            this.carButton.TabIndex = 10;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicyleButton
            // 
            this.bicyleButton.Location = new System.Drawing.Point(851, 98);
            this.bicyleButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bicyleButton.Name = "bicyleButton";
            this.bicyleButton.Size = new System.Drawing.Size(112, 35);
            this.bicyleButton.TabIndex = 11;
            this.bicyleButton.Text = "bicyle";
            this.bicyleButton.UseVisualStyleBackColor = true;
            this.bicyleButton.Click += new System.EventHandler(this.bicyleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(120, 172);
            this.beautifulButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(112, 35);
            this.beautifulButton.TabIndex = 12;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(284, 172);
            this.bigButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(112, 35);
            this.bigButton.TabIndex = 13;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(521, 172);
            this.smallButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(112, 35);
            this.smallButton.TabIndex = 14;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(718, 172);
            this.strangeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(112, 35);
            this.strangeButton.TabIndex = 15;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(231, 246);
            this.rodeButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(112, 35);
            this.rodeButton.TabIndex = 16;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // lookedAtButton
            // 
            this.lookedAtButton.Location = new System.Drawing.Point(18, 246);
            this.lookedAtButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lookedAtButton.Name = "lookedAtButton";
            this.lookedAtButton.Size = new System.Drawing.Size(112, 35);
            this.lookedAtButton.TabIndex = 17;
            this.lookedAtButton.Text = "looked at";
            this.lookedAtButton.UseVisualStyleBackColor = true;
            this.lookedAtButton.Click += new System.EventHandler(this.lookedAtButton_Click);
            // 
            // spokeToButton
            // 
            this.spokeToButton.Location = new System.Drawing.Point(433, 246);
            this.spokeToButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.spokeToButton.Name = "spokeToButton";
            this.spokeToButton.Size = new System.Drawing.Size(112, 35);
            this.spokeToButton.TabIndex = 18;
            this.spokeToButton.Text = "spoke to";
            this.spokeToButton.UseVisualStyleBackColor = true;
            this.spokeToButton.Click += new System.EventHandler(this.spokeToButton_Click);
            // 
            // laughedAtButton
            // 
            this.laughedAtButton.Location = new System.Drawing.Point(624, 246);
            this.laughedAtButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.laughedAtButton.Name = "laughedAtButton";
            this.laughedAtButton.Size = new System.Drawing.Size(112, 35);
            this.laughedAtButton.TabIndex = 19;
            this.laughedAtButton.Text = "laughed at";
            this.laughedAtButton.UseVisualStyleBackColor = true;
            this.laughedAtButton.Click += new System.EventHandler(this.laughedAtButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(851, 246);
            this.droveButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(112, 35);
            this.droveButton.TabIndex = 20;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.Location = new System.Drawing.Point(160, 325);
            this.spaceButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(112, 35);
            this.spaceButton.TabIndex = 21;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // exoButton
            // 
            this.exoButton.Location = new System.Drawing.Point(624, 325);
            this.exoButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exoButton.Name = "exoButton";
            this.exoButton.Size = new System.Drawing.Size(112, 35);
            this.exoButton.TabIndex = 22;
            this.exoButton.Text = "!";
            this.exoButton.UseVisualStyleBackColor = true;
            this.exoButton.Click += new System.EventHandler(this.exoButton_Click);
            // 
            // peiodButton
            // 
            this.peiodButton.Location = new System.Drawing.Point(392, 325);
            this.peiodButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.peiodButton.Name = "peiodButton";
            this.peiodButton.Size = new System.Drawing.Size(112, 35);
            this.peiodButton.TabIndex = 23;
            this.peiodButton.Text = ".";
            this.peiodButton.UseVisualStyleBackColor = true;
            this.peiodButton.Click += new System.EventHandler(this.peiodButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(219, 484);
            this.clearButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(112, 35);
            this.clearButton.TabIndex = 24;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(521, 484);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 35);
            this.exitButton.TabIndex = 25;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.Location = new System.Drawing.Point(18, 395);
            this.sentenceLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(847, 38);
            this.sentenceLabel.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1009, 611);
            this.Controls.Add(this.sentenceLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.peiodButton);
            this.Controls.Add(this.exoButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedAtButton);
            this.Controls.Add(this.spokeToButton);
            this.Controls.Add(this.lookedAtButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicyleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.theLowerButton);
            this.Controls.Add(this.theUpperButton);
            this.Controls.Add(this.anLowerButton);
            this.Controls.Add(this.anUpperButton);
            this.Controls.Add(this.aLowerButton);
            this.Controls.Add(this.aUpperButton);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button aUpperButton;
        private System.Windows.Forms.Button aLowerButton;
        private System.Windows.Forms.Button anUpperButton;
        private System.Windows.Forms.Button anLowerButton;
        private System.Windows.Forms.Button theUpperButton;
        private System.Windows.Forms.Button theLowerButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicyleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button lookedAtButton;
        private System.Windows.Forms.Button spokeToButton;
        private System.Windows.Forms.Button laughedAtButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button exoButton;
        private System.Windows.Forms.Button peiodButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label sentenceLabel;
    }
}

