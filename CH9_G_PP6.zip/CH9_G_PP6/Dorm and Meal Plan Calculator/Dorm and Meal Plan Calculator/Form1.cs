﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 05/11/18
 * CSC 153
 * Brian Schweikart
 * Dorm Meal Plan Calculator
 */

namespace Dorm_and_Meal_Plan_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            // Define Variables
            int dormAmount = 0;
            int mealAmount = 0;
            int total = 0;

            // creat object of total dispaly form
            TotalCharge tdobj = new TotalCharge();

            // Check type of drom and set dorm amount
            if (dormListBox.SelectedItem.ToString() == "Allen Hall")
            {
                // Set dorm amount
                dormAmount = 1500;
            }
            else if (dormListBox.SelectedItem.ToString() == "Pike Hall")
            {
                // Set dorm amount
                dormAmount = 1600;
            }

            else if (dormListBox.SelectedItem.ToString() == "Farthing Hall")
            {
                // Set dorm amount
                dormAmount = 1800;
            }

            else if (dormListBox.SelectedItem.ToString() == "University Suites")
            {
                // Set dorm amount
                dormAmount = 2500;
            }

            if (mealListBox.SelectedItem.ToString() == "7 meals per week")
            {
                // set the meal amount
                mealAmount = 600;
            }

            else if (mealListBox.SelectedItem.ToString() == "14 meals per week")
            {
                // set the meal amount
                mealAmount = 1200;
            }

            else if (mealListBox.SelectedItem.ToString() == "Unlimited meals")
            {
                // set the meal amount
                mealAmount = 1700;
            }

            // add dorm and meal charges to total label
            tdobj.displayTotalLabel.Text = "Dorm Charges: " + dormAmount.ToString("c") + "\n";

            tdobj.displayTotalLabel.Text += "Meal Charges: " + mealAmount.ToString("c") + "\n";

            // Calculate the total price.
            total = dormAmount + mealAmount;

            // Access the total lable form
            tdobj.displayTotalLabel.Text += "Total" + " Charges: " + total.ToString("c");

            // show the total form
            tdobj.ShowDialog();
        }

        // Close this form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
