﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dorm_and_Meal_Plan_Calculator
{
    public partial class TotalCharge : Form
    {
        public TotalCharge()
        {
            InitializeComponent();
        }

        // Close this form
        private void closeButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
