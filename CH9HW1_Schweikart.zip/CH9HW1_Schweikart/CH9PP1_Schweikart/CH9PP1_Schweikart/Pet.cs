﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH9PP1_Schweikart
{
    class Pet
    {
        // Fields to store Pet data
        // Name,type, and age

        private string _Name;
        private string _Type;
        private int _Age;

        public Pet()
        {
            _Name = "";
            _Type = "";
            _Age = 0;
        }

        public Pet(string Name, string Type, int Age)
        {
            _Name = "";
            _Type = "";
            _Age = Age;
        }

        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }

        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }

        public int Age
        {
            get { return _Age; }
            set { _Age = value; }
        }


    }
}
