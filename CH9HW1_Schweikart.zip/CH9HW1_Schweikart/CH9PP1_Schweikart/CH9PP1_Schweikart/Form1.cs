﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 05/08/18
 * CSC 153
 * Brian Schweikart
 * Pet Class
 */

namespace CH9PP1_Schweikart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Call the method for Pet Class
        private void GetPetObjectData(Pet petObject)
        {
            // Hold age of pet
            Int32 age;

            //Get Pets name
            petObject.Name = nameTextBox.Text;

            // Get Pets Type
            petObject.Type = typeTextBox.Text;

            // Get Pets Age
            if(Int32.TryParse(ageTextBox.Text, out age))
            {
                petObject.Age = age;
            }
            else
            {
                // Dispaly an error message
                MessageBox.Show("Invalid age");
            }
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            Pet petObject = new Pet();
            GetPetObjectData(petObject);

            namelabel.Text = petObject.Name;
            typeLabel.Text = petObject.Type;

            ageLabel.Text = petObject.Age.ToString("0");
        }

        // Close the form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
