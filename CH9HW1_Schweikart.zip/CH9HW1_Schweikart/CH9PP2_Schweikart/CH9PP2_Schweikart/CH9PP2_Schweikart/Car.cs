﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CH9PP2_Schweikart
{
    class Car
    {
        // fields for the car class
        private int _year;
        private string _make;
        private int _speed;

        // Constructor set for year,type, and model
        public Car(int year, string make)
        {
            _year = year;
            _make = make;

            // set starting speed @ 0
            _speed = 0;
        }

        // year property
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        // make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        // speed propert
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        // Accelerate car speed by 5 per click
        public void accelerate()
        {
            _speed = _speed + 5;
        }

        // Brake the car by 5 per click
        public void brake()
        {
            _speed = _speed - 5;
        }
    }
}
