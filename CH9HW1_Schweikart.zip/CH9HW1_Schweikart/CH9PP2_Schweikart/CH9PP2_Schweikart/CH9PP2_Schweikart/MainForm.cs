﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 05/09/18
 * CSC 153
 * Brian Schweikart
 * Car Class
 */

namespace CH9PP2_Schweikart
{
    public partial class MainForm : Form
    {
        private Car car = new Car(2000, "BMW");
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            yearLabel.Text = car.Year.ToString();

            makeLabel.Text = car.Make;

            speedLabel.Text = car.Speed.ToString();
        }

        private void acceleratebutton_Click(object sender, EventArgs e)
        {
            car.accelerate();

            speedLabel.Text = car.Speed.ToString("0");
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            if (car.Speed == 0)
            {
                MessageBox.Show("Speed Error");
            }
            else
            {
                car.brake();
                speedLabel.Text = car.Speed.ToString("0");
            }           
        }
    }
}
