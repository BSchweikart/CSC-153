﻿namespace Card_Identifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.king_clubs_pictureBox = new System.Windows.Forms.PictureBox();
            this.two_hearts_pictureBox = new System.Windows.Forms.PictureBox();
            this.ace_spades_pictureBox = new System.Windows.Forms.PictureBox();
            this.nine_clubs_pictureBox = new System.Windows.Forms.PictureBox();
            this.jack_dimond_pictureBox = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.intructionLabel = new System.Windows.Forms.Label();
            this.suiteLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.king_clubs_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.two_hearts_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ace_spades_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nine_clubs_pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jack_dimond_pictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // king_clubs_pictureBox
            // 
            this.king_clubs_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("king_clubs_pictureBox.Image")));
            this.king_clubs_pictureBox.Location = new System.Drawing.Point(12, 112);
            this.king_clubs_pictureBox.Name = "king_clubs_pictureBox";
            this.king_clubs_pictureBox.Size = new System.Drawing.Size(136, 192);
            this.king_clubs_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.king_clubs_pictureBox.TabIndex = 0;
            this.king_clubs_pictureBox.TabStop = false;
            this.king_clubs_pictureBox.Click += new System.EventHandler(this.king_clubs_pictureBox_Click);
            // 
            // two_hearts_pictureBox
            // 
            this.two_hearts_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("two_hearts_pictureBox.Image")));
            this.two_hearts_pictureBox.Location = new System.Drawing.Point(154, 112);
            this.two_hearts_pictureBox.Name = "two_hearts_pictureBox";
            this.two_hearts_pictureBox.Size = new System.Drawing.Size(136, 192);
            this.two_hearts_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.two_hearts_pictureBox.TabIndex = 1;
            this.two_hearts_pictureBox.TabStop = false;
            this.two_hearts_pictureBox.Click += new System.EventHandler(this.two_hearts_pictureBox_Click);
            // 
            // ace_spades_pictureBox
            // 
            this.ace_spades_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("ace_spades_pictureBox.Image")));
            this.ace_spades_pictureBox.Location = new System.Drawing.Point(296, 112);
            this.ace_spades_pictureBox.Name = "ace_spades_pictureBox";
            this.ace_spades_pictureBox.Size = new System.Drawing.Size(136, 192);
            this.ace_spades_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ace_spades_pictureBox.TabIndex = 2;
            this.ace_spades_pictureBox.TabStop = false;
            this.ace_spades_pictureBox.Click += new System.EventHandler(this.ace_spades_pictureBox_Click);
            // 
            // nine_clubs_pictureBox
            // 
            this.nine_clubs_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("nine_clubs_pictureBox.Image")));
            this.nine_clubs_pictureBox.Location = new System.Drawing.Point(438, 112);
            this.nine_clubs_pictureBox.Name = "nine_clubs_pictureBox";
            this.nine_clubs_pictureBox.Size = new System.Drawing.Size(136, 192);
            this.nine_clubs_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.nine_clubs_pictureBox.TabIndex = 3;
            this.nine_clubs_pictureBox.TabStop = false;
            this.nine_clubs_pictureBox.Click += new System.EventHandler(this.nine_clubs_pictureBox_Click);
            // 
            // jack_dimond_pictureBox
            // 
            this.jack_dimond_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("jack_dimond_pictureBox.Image")));
            this.jack_dimond_pictureBox.Location = new System.Drawing.Point(580, 112);
            this.jack_dimond_pictureBox.Name = "jack_dimond_pictureBox";
            this.jack_dimond_pictureBox.Size = new System.Drawing.Size(136, 192);
            this.jack_dimond_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.jack_dimond_pictureBox.TabIndex = 4;
            this.jack_dimond_pictureBox.TabStop = false;
            this.jack_dimond_pictureBox.Click += new System.EventHandler(this.jack_dimond_pictureBox_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(244, 406);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(188, 52);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // intructionLabel
            // 
            this.intructionLabel.AutoSize = true;
            this.intructionLabel.Location = new System.Drawing.Point(220, 30);
            this.intructionLabel.Name = "intructionLabel";
            this.intructionLabel.Size = new System.Drawing.Size(212, 20);
            this.intructionLabel.TabIndex = 6;
            this.intructionLabel.Text = "Click a Card to See Its Name";
            // 
            // suiteLabel
            // 
            this.suiteLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.suiteLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.suiteLabel.Location = new System.Drawing.Point(224, 343);
            this.suiteLabel.Name = "suiteLabel";
            this.suiteLabel.Size = new System.Drawing.Size(239, 33);
            this.suiteLabel.TabIndex = 7;
            this.suiteLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 556);
            this.Controls.Add(this.suiteLabel);
            this.Controls.Add(this.intructionLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.jack_dimond_pictureBox);
            this.Controls.Add(this.nine_clubs_pictureBox);
            this.Controls.Add(this.ace_spades_pictureBox);
            this.Controls.Add(this.two_hearts_pictureBox);
            this.Controls.Add(this.king_clubs_pictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.king_clubs_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.two_hearts_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ace_spades_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nine_clubs_pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jack_dimond_pictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox king_clubs_pictureBox;
        private System.Windows.Forms.PictureBox two_hearts_pictureBox;
        private System.Windows.Forms.PictureBox ace_spades_pictureBox;
        private System.Windows.Forms.PictureBox nine_clubs_pictureBox;
        private System.Windows.Forms.PictureBox jack_dimond_pictureBox;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label intructionLabel;
        private System.Windows.Forms.Label suiteLabel;
    }
}

