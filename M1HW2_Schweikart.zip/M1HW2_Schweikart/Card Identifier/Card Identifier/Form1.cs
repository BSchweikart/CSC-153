﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 02/02/18
* CSC 153
* Brian Schweikart
* Card identifier
*/

// Upon clicking on the card show the Name and Suite.
namespace Card_Identifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void king_clubs_pictureBox_Click(object sender, EventArgs e)
        {
            // On card click show name
            suiteLabel.Text = "King of Clubs";
        }

        private void two_hearts_pictureBox_Click(object sender, EventArgs e)
        {
            // On card click show name
            suiteLabel.Text = "Two of Hearts";
        }

        private void ace_spades_pictureBox_Click(object sender, EventArgs e)
        {
            // On card click show name
            suiteLabel.Text = "Ace of Spades";
        }

        private void nine_clubs_pictureBox_Click(object sender, EventArgs e)
        {
            // On card click show name
            suiteLabel.Text = "Nine of Clubs";
        }

        private void jack_dimond_pictureBox_Click(object sender, EventArgs e)
        {
            // On card click show name
            suiteLabel.Text = "Jack of Dimonds";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
