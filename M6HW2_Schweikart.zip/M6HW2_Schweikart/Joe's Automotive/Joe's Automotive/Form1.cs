﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 4/17/2018
* CSC 153
* Brian Schweikart
* Joe's Automotive
*/

namespace Joe_s_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // See if Boxes are checked and set price
        // Set group items
        // Set group items to string
        private void calculateButton_Click(object sender, EventArgs e)
        {
            double oil = 0, lube = 0, radiator = 0, trans = 0, inspection = 0, muffler = 0, tire = 0;

            if (oilCheckBox.Checked == true)
            {
                oil = 26;
            }

            if (lubeCheckBox.Checked == true)
            {
                lube = 18;
            }

            if (radCheckBox.Checked == true)
            {
                radiator = 30;
            }

            if (transCheckBox.Checked == true)
            {
                trans = 80;
            }

            if (inspectCheckBox.Checked == true)
            {
                inspection = 15;
            }

            if (mufflerCheckBox.Checked == true)
            {
                muffler = 100
                    ;
            }

            if (tireCheckBox.Checked == true)
            {
                tire = 20;
            }

            double parts = double.Parse(partsTextBox.Text);
            double labor = double.Parse(LaborTextBox.Text);
            double oillube = OilLubeCharges(oil, lube);
            double flush = FlushCharges(radiator, trans);
            double misc = MiscCharges(inspection, muffler, tire);
            double other = OtherCharges(parts, labor);
            double tax = TaxCharges(parts, labor, oillube, flush, misc, labor);
            double total = TotalCharges(oillube, flush, misc, other, tax);
            double services = oillube + flush + misc;

            serLaborTextBox.Text = services.ToString();
            partsSumTextBox.Text = other.ToString();
            taxPartTextBox.Text = tax.ToString();
            totalTextBox.Text = total.ToString();
        }

        // Calculate total per group by adding selections
        private double OilLubeCharges(double oil, double lube)
        {
            return oil + lube;
        }

        private double FlushCharges(double radiator, double trans)
        {
            return radiator + trans;
        }

        private double MiscCharges(double inspection, double muffler, double tire)
        {
            return inspection + muffler + tire;
        }

        // Add parts + labor
        private double OtherCharges(double parts, double labor)
        {
            return parts + labor;
        }

        // Calculate Tax charge
        private double TaxCharges(double parts, double labor, double oillube, double flush, double misc, double other)
        {
            if (parts != 0 && labor != 0 && (oillube != 0 && flush != 0 && misc != 0 && other != 0))
            {
                return (0.06 * parts);
            }
            else
                return 0;
        }

        // Calculate Total
        private double TotalCharges(double oillube, double flush, double misc, double other, double tax)
        {
            return oillube + flush + misc + other + tax;
        }


        // Clear the Form
        private void clearButton_Click(object sender, EventArgs e)
        {
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void ClearOilLube()
        {
            if(oilCheckBox.Checked == true)
            {
                oilCheckBox.Checked = false;
            }

            if(lubeCheckBox.Checked == true)
            {
                lubeCheckBox.Checked = false;
            }
        }

        private void ClearFlushes()
        {
            if (radCheckBox.Checked == true)
            {
                radCheckBox.Checked = false;
            }

            if (transCheckBox.Checked == true)
            {
                transCheckBox.Checked = false;
            }
        }

        private void ClearMisc()
        {
            if (inspectCheckBox.Checked == true)
            {
                inspectCheckBox.Checked = false;
            }

            if (mufflerCheckBox.Checked == true)
            {
                mufflerCheckBox.Checked = false;
            }

            if (tireCheckBox.Checked == true)
            {
                tireCheckBox.Checked = false;
            }

        }

        private void ClearOther()
        {
            partsTextBox.Text = null;
            LaborTextBox.Text = null;

        }

        private void ClearFees()
        {
            serLaborTextBox.Text = null;
            partsSumTextBox.Text = null;
            taxPartTextBox.Text = null;
            totalTextBox.Text = null;
        }

        // Close the Form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
