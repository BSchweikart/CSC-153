﻿namespace Joe_s_Automotive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.oilCheckBox = new System.Windows.Forms.CheckBox();
            this.lubeCheckBox = new System.Windows.Forms.CheckBox();
            this.radCheckBox = new System.Windows.Forms.CheckBox();
            this.transCheckBox = new System.Windows.Forms.CheckBox();
            this.tireCheckBox = new System.Windows.Forms.CheckBox();
            this.mufflerCheckBox = new System.Windows.Forms.CheckBox();
            this.inspectCheckBox = new System.Windows.Forms.CheckBox();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.LaborTextBox = new System.Windows.Forms.TextBox();
            this.partsLabel = new System.Windows.Forms.Label();
            this.laborLabel = new System.Windows.Forms.Label();
            this.serLaborLabel = new System.Windows.Forms.Label();
            this.partsSumLabel = new System.Windows.Forms.Label();
            this.taxPartLabel = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.serLaborTextBox = new System.Windows.Forms.TextBox();
            this.partsSumTextBox = new System.Windows.Forms.TextBox();
            this.taxPartTextBox = new System.Windows.Forms.TextBox();
            this.totalTextBox = new System.Windows.Forms.TextBox();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.oilCheckBox);
            this.groupBox1.Controls.Add(this.lubeCheckBox);
            this.groupBox1.Location = new System.Drawing.Point(20, 48);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(240, 100);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oil and Lube";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radCheckBox);
            this.groupBox2.Controls.Add(this.transCheckBox);
            this.groupBox2.Location = new System.Drawing.Point(288, 48);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(240, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Flushes";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.tireCheckBox);
            this.groupBox3.Controls.Add(this.mufflerCheckBox);
            this.groupBox3.Controls.Add(this.inspectCheckBox);
            this.groupBox3.Location = new System.Drawing.Point(20, 205);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(240, 177);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Misc";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.laborLabel);
            this.groupBox4.Controls.Add(this.LaborTextBox);
            this.groupBox4.Controls.Add(this.partsLabel);
            this.groupBox4.Controls.Add(this.partsTextBox);
            this.groupBox4.Location = new System.Drawing.Point(288, 205);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(240, 177);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parts and Labor";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.serLaborTextBox);
            this.groupBox5.Controls.Add(this.totalTextBox);
            this.groupBox5.Controls.Add(this.taxPartTextBox);
            this.groupBox5.Controls.Add(this.partsSumTextBox);
            this.groupBox5.Controls.Add(this.partsSumLabel);
            this.groupBox5.Controls.Add(this.taxPartLabel);
            this.groupBox5.Controls.Add(this.totalLabel);
            this.groupBox5.Controls.Add(this.serLaborLabel);
            this.groupBox5.Location = new System.Drawing.Point(31, 467);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(507, 401);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Summary";
            // 
            // oilCheckBox
            // 
            this.oilCheckBox.AutoSize = true;
            this.oilCheckBox.Location = new System.Drawing.Point(7, 25);
            this.oilCheckBox.Name = "oilCheckBox";
            this.oilCheckBox.Size = new System.Drawing.Size(176, 24);
            this.oilCheckBox.TabIndex = 2;
            this.oilCheckBox.Text = "Oil Change ($26.00)";
            this.oilCheckBox.UseVisualStyleBackColor = true;
            // 
            // lubeCheckBox
            // 
            this.lubeCheckBox.AutoSize = true;
            this.lubeCheckBox.Location = new System.Drawing.Point(7, 70);
            this.lubeCheckBox.Name = "lubeCheckBox";
            this.lubeCheckBox.Size = new System.Drawing.Size(159, 24);
            this.lubeCheckBox.TabIndex = 3;
            this.lubeCheckBox.Text = "Lube job ($18.00)";
            this.lubeCheckBox.UseVisualStyleBackColor = true;
            // 
            // radCheckBox
            // 
            this.radCheckBox.AutoSize = true;
            this.radCheckBox.Location = new System.Drawing.Point(6, 35);
            this.radCheckBox.Name = "radCheckBox";
            this.radCheckBox.Size = new System.Drawing.Size(202, 24);
            this.radCheckBox.TabIndex = 4;
            this.radCheckBox.Text = "Radiator Flush ($30.00)";
            this.radCheckBox.UseVisualStyleBackColor = true;
            // 
            // transCheckBox
            // 
            this.transCheckBox.AutoSize = true;
            this.transCheckBox.Location = new System.Drawing.Point(6, 65);
            this.transCheckBox.Name = "transCheckBox";
            this.transCheckBox.Size = new System.Drawing.Size(234, 24);
            this.transCheckBox.TabIndex = 5;
            this.transCheckBox.Text = "Transmission Flush ($80.00)";
            this.transCheckBox.UseVisualStyleBackColor = true;
            // 
            // tireCheckBox
            // 
            this.tireCheckBox.AutoSize = true;
            this.tireCheckBox.Location = new System.Drawing.Point(11, 131);
            this.tireCheckBox.Name = "tireCheckBox";
            this.tireCheckBox.Size = new System.Drawing.Size(189, 24);
            this.tireCheckBox.TabIndex = 6;
            this.tireCheckBox.Text = "Tire Rotation ($20.00)";
            this.tireCheckBox.UseVisualStyleBackColor = true;
            // 
            // mufflerCheckBox
            // 
            this.mufflerCheckBox.AutoSize = true;
            this.mufflerCheckBox.Location = new System.Drawing.Point(11, 78);
            this.mufflerCheckBox.Name = "mufflerCheckBox";
            this.mufflerCheckBox.Size = new System.Drawing.Size(219, 24);
            this.mufflerCheckBox.TabIndex = 7;
            this.mufflerCheckBox.Text = "Replace Muffler ($100.00)";
            this.mufflerCheckBox.UseVisualStyleBackColor = true;
            // 
            // inspectCheckBox
            // 
            this.inspectCheckBox.AutoSize = true;
            this.inspectCheckBox.Location = new System.Drawing.Point(11, 36);
            this.inspectCheckBox.Name = "inspectCheckBox";
            this.inspectCheckBox.Size = new System.Drawing.Size(172, 24);
            this.inspectCheckBox.TabIndex = 8;
            this.inspectCheckBox.Text = "Inspection ($15.00)";
            this.inspectCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(134, 46);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(100, 26);
            this.partsTextBox.TabIndex = 2;
            // 
            // LaborTextBox
            // 
            this.LaborTextBox.Location = new System.Drawing.Point(134, 103);
            this.LaborTextBox.Name = "LaborTextBox";
            this.LaborTextBox.Size = new System.Drawing.Size(100, 26);
            this.LaborTextBox.TabIndex = 3;
            // 
            // partsLabel
            // 
            this.partsLabel.AutoSize = true;
            this.partsLabel.Location = new System.Drawing.Point(27, 46);
            this.partsLabel.Name = "partsLabel";
            this.partsLabel.Size = new System.Drawing.Size(46, 20);
            this.partsLabel.TabIndex = 2;
            this.partsLabel.Text = "Parts";
            // 
            // laborLabel
            // 
            this.laborLabel.AutoSize = true;
            this.laborLabel.Location = new System.Drawing.Point(27, 109);
            this.laborLabel.Name = "laborLabel";
            this.laborLabel.Size = new System.Drawing.Size(73, 20);
            this.laborLabel.TabIndex = 3;
            this.laborLabel.Text = "Labor ($)";
            // 
            // serLaborLabel
            // 
            this.serLaborLabel.AutoSize = true;
            this.serLaborLabel.Location = new System.Drawing.Point(6, 61);
            this.serLaborLabel.Name = "serLaborLabel";
            this.serLaborLabel.Size = new System.Drawing.Size(137, 20);
            this.serLaborLabel.TabIndex = 2;
            this.serLaborLabel.Text = "Service and Labor";
            // 
            // partsSumLabel
            // 
            this.partsSumLabel.AutoSize = true;
            this.partsSumLabel.Location = new System.Drawing.Point(6, 120);
            this.partsSumLabel.Name = "partsSumLabel";
            this.partsSumLabel.Size = new System.Drawing.Size(46, 20);
            this.partsSumLabel.TabIndex = 3;
            this.partsSumLabel.Text = "Parts";
            // 
            // taxPartLabel
            // 
            this.taxPartLabel.AutoSize = true;
            this.taxPartLabel.Location = new System.Drawing.Point(6, 187);
            this.taxPartLabel.Name = "taxPartLabel";
            this.taxPartLabel.Size = new System.Drawing.Size(106, 20);
            this.taxPartLabel.TabIndex = 4;
            this.taxPartLabel.Text = "Tax (on parts)";
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Location = new System.Drawing.Point(6, 262);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(84, 20);
            this.totalLabel.TabIndex = 5;
            this.totalLabel.Text = "Total Fees";
            // 
            // serLaborTextBox
            // 
            this.serLaborTextBox.Location = new System.Drawing.Point(166, 55);
            this.serLaborTextBox.Name = "serLaborTextBox";
            this.serLaborTextBox.Size = new System.Drawing.Size(100, 26);
            this.serLaborTextBox.TabIndex = 2;
            // 
            // partsSumTextBox
            // 
            this.partsSumTextBox.Location = new System.Drawing.Point(166, 114);
            this.partsSumTextBox.Name = "partsSumTextBox";
            this.partsSumTextBox.Size = new System.Drawing.Size(100, 26);
            this.partsSumTextBox.TabIndex = 3;
            // 
            // taxPartTextBox
            // 
            this.taxPartTextBox.Location = new System.Drawing.Point(166, 181);
            this.taxPartTextBox.Name = "taxPartTextBox";
            this.taxPartTextBox.Size = new System.Drawing.Size(100, 26);
            this.taxPartTextBox.TabIndex = 6;
            // 
            // totalTextBox
            // 
            this.totalTextBox.Location = new System.Drawing.Point(166, 256);
            this.totalTextBox.Name = "totalTextBox";
            this.totalTextBox.Size = new System.Drawing.Size(100, 26);
            this.totalTextBox.TabIndex = 7;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(31, 905);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(122, 40);
            this.calculateButton.TabIndex = 2;
            this.calculateButton.Text = "Calculate Total";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(227, 905);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(122, 40);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(423, 905);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(115, 40);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 1158);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Joe\'s Automotive";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox oilCheckBox;
        private System.Windows.Forms.CheckBox lubeCheckBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox radCheckBox;
        private System.Windows.Forms.CheckBox transCheckBox;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox tireCheckBox;
        private System.Windows.Forms.CheckBox mufflerCheckBox;
        private System.Windows.Forms.CheckBox inspectCheckBox;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label laborLabel;
        private System.Windows.Forms.TextBox LaborTextBox;
        private System.Windows.Forms.Label partsLabel;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox serLaborTextBox;
        private System.Windows.Forms.TextBox totalTextBox;
        private System.Windows.Forms.TextBox taxPartTextBox;
        private System.Windows.Forms.TextBox partsSumTextBox;
        private System.Windows.Forms.Label partsSumLabel;
        private System.Windows.Forms.Label taxPartLabel;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label serLaborLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

