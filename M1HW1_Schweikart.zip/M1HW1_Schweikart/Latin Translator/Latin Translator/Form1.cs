﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 02/01/18
 * CSC 153
 * Brian Schweikart
 * Latin Translator
 * */

// Translation of Latin words to English
namespace Form1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sinisterButton_Click(object sender, EventArgs e)
        {
            // translation of sinister to english
            translationLabel.Text = "Left";
        }

        private void dexterButton_Click(object sender, EventArgs e)
        {
            // translation of dexter to English
            translationLabel.Text = "Right";
        }

        private void MediumButton_Click(object sender, EventArgs e)
        {
            // translation of medium to English
            translationLabel.Text = "Center";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //close this form
            this.Close();
        }
    }
}
