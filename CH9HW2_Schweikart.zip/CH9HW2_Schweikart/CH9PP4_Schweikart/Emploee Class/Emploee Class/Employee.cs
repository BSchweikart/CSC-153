﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emploee_Class
{   // Class to set name, ID, number, department, and position
    public class Employee
    {
        // fields for Employee class
        private string _name;
        private decimal _idNumber;
        private string _department;
        private string _position;

        // Set the default values of the fields
        public Employee()
        {
            _name = "";
            _idNumber = 0;
            _department = "";
            _position = "";
        }

        // Constructor to set name, ID, number, department, and position
        public Employee(string name, decimal idNumber, string department, string position)
        {
            _name = name;
            _idNumber = idNumber;
            _department = department;
            _position = position;
        }

        // Constructor to set name and id number along with empty string w/department and postion
        public Employee(string name, decimal idNumber)
        {
            _name = name;
            _idNumber = idNumber;
            _department = "";
            _position = "";
        }

        // Property to hold name
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }

        // Property to hold idNumber
        public decimal IdNumber
        {
            set { _idNumber = value; }
            get { return _idNumber; }
        }

        // Property to hold department
        public string Department
        {
            set { _department = value; }
            get { return _department; }
        }

        // Property to hold postion
        public string Position
        {
            set { _position = value; }
            get { return _position; }
        }
    }
}
