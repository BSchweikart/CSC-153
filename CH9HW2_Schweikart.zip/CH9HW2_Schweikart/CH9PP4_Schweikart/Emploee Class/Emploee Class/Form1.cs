﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 05/10/18
 * CSC 153
 * Brian Schwiekart
 * Employee Class
 */

namespace Emploee_Class
{
    public partial class Form1 : Form
    {
        private Employee employee1 = new Employee("Susan Neyers", 47899, "Accounting", "Vice President");
        private Employee employee2 = new Employee("Mark Jones", 39119, "IT", "Programer");
        private Employee employee3 = new Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            employee1TextBox.Text = employee1.Name + "," + employee1.IdNumber + "," + employee1.Department + "," + employee1.Position;
            employee2TextBox.Text = employee2.Name + "," + employee2.IdNumber + "," + employee2.Department + "," + employee2.Position;
            employee3TextBox.Text = employee3.Name + "," + employee3.IdNumber + "," + employee3.Department + "," + employee3.Position;
        }

        // Close this Form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
