﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
 * 05/11/18
 * CSC 153
 * Brian Schweikart
 * Person Information Class
 */

namespace Personal_Information_Class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Person[] familyMembers = new Person[3];
        private void Form1_Load(object sender, EventArgs e)
        {
            // Load the object information when the form is loaded
            // information in the Person array
            // object at index 0
            familyMembers[0] = new Person();
            familyMembers[0].Name = "Brian";
            familyMembers[0].Address = "Fayetteville, North Carolina";
            familyMembers[0].Age = 29;
            familyMembers[0].PhoneNumber = "910-551-1234";
            
            // Set index at 1
            familyMembers[1] = new Person();
            familyMembers[1].Name = "Bobbie";
            familyMembers[1].Address = "Madison, Alabama";
            familyMembers[1].Age = 55;
            familyMembers[1].PhoneNumber = "555-555-5555";

            // Set index at 2
            familyMembers[2] = new Person();
            familyMembers[2].Name = "Mia";
            familyMembers[2].Address = "Fayetteville, North Carolina";
            familyMembers[2].Age = 56;
            familyMembers[2].PhoneNumber = "910-551-5678";
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // Dispaly information in text box
            myTextBox.Text = familyMembers[0].Name + "," +
            familyMembers[0].Address + "," +
            familyMembers[0].Age + "," +
            familyMembers[0].PhoneNumber;

            // Display information in father text box
            fatherTextBox.Text = familyMembers[1].Name + "," +
            familyMembers[1].Address + "," +
            familyMembers[1].Age + "," +
            familyMembers[1].PhoneNumber;

            // Display information in Mom text box
            momTextBox.Text = familyMembers[2].Name + "," +
            familyMembers[2].Address + "," +
            familyMembers[2].Age + "," +
            familyMembers[2].PhoneNumber;
        }

        // Close this form
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
