﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 04/15/2018
* CSC 153
* Brian Schweikart
* Falling Distance
*/

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            
            double time, value;

            // Get user input for total time of fall
            time = double.Parse(timeTextBox.Text);
            value = FallingDistance(time);

            // Show what the total speed of the object is
            MessageBox.Show("Distance of the object is:" + value + "m/sec");
        }

        private double FallingDistance(double time)
        {
            // what (G) is * time
            return 0.5 * 9.8 * (time * time);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
