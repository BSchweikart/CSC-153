﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


/**
* 02/25/2018
* CSC 153
* Brian Schweikart
* Roman numeral Converter
*/

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            int number = 0;

            // If a non number is entered display error point.
            // If a number is entered move to Convert/Roman
            if (arabicNumberTextBox.Text != "")
            {
                int.TryParse(arabicNumberTextBox.Text, out number);
            }
            else
            {
                errorProvider1.SetError(arabicNumberTextBox, "need a number");
            }
                    
            // Convert Arabic numbers to Roman numerals.
            if (number == 1)
            {
                romanNumeralLabel.Text = ("I");
            }

                if (number == 2)
                {
                    romanNumeralLabel.Text = ("II");
                }

                if (number == 3)
                {
                    romanNumeralLabel.Text = ("III");
                }

                if (number == 4)
                {
                    romanNumeralLabel.Text = ("IV");
                }

                if (number == 5)
                {
                    romanNumeralLabel.Text = ("V");
                }

                if (number == 6)
                {
                    romanNumeralLabel.Text = ("VI");
                }

                if (number == 7)
                {
                    romanNumeralLabel.Text = ("VII");
                }

                if (number == 8)
                {
                    romanNumeralLabel.Text = ("VIII");
                }

                if (number == 9)
                {
                    romanNumeralLabel.Text = ("IX");
                }

                if (number == 10)
                {
                    romanNumeralLabel.Text = ("X");
                }

            if (number < 1 || number > 10 || arabicNumberTextBox.Text == "")
            {
                // Display error mark next to inputbox.
                errorProvider1.SetError(arabicNumberTextBox, "Must input a number from 1-10");
            }

            else
            {
                // Clear error.
                errorProvider1.Clear();
            }
                       
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the input/output boxes
            arabicNumberTextBox.Text = ("");
            romanNumeralLabel.Text = ("");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
