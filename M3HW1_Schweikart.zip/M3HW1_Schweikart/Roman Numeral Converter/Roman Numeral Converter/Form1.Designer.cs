﻿namespace Roman_Numeral_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.convertButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.arabicLabel = new System.Windows.Forms.Label();
            this.romanLabel = new System.Windows.Forms.Label();
            this.romanNumeralLabel = new System.Windows.Forms.Label();
            this.arabicNumberTextBox = new System.Windows.Forms.TextBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // convertButton
            // 
            this.convertButton.Location = new System.Drawing.Point(25, 120);
            this.convertButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.convertButton.Name = "convertButton";
            this.convertButton.Size = new System.Drawing.Size(67, 38);
            this.convertButton.TabIndex = 0;
            this.convertButton.Text = "Convert Number";
            this.convertButton.UseVisualStyleBackColor = true;
            this.convertButton.Click += new System.EventHandler(this.convertButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(115, 120);
            this.clearButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(50, 38);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(195, 120);
            this.exitButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(50, 38);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // arabicLabel
            // 
            this.arabicLabel.AutoSize = true;
            this.arabicLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arabicLabel.Location = new System.Drawing.Point(22, 31);
            this.arabicLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.arabicLabel.Name = "arabicLabel";
            this.arabicLabel.Size = new System.Drawing.Size(126, 13);
            this.arabicLabel.TabIndex = 3;
            this.arabicLabel.Text = "Enter a number 1-10:";
            // 
            // romanLabel
            // 
            this.romanLabel.AutoSize = true;
            this.romanLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.romanLabel.Location = new System.Drawing.Point(48, 58);
            this.romanLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.romanLabel.Name = "romanLabel";
            this.romanLabel.Size = new System.Drawing.Size(100, 13);
            this.romanLabel.TabIndex = 4;
            this.romanLabel.Text = "Roman Numeral:";
            // 
            // romanNumeralLabel
            // 
            this.romanNumeralLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.romanNumeralLabel.Location = new System.Drawing.Point(167, 58);
            this.romanNumeralLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.romanNumeralLabel.Name = "romanNumeralLabel";
            this.romanNumeralLabel.Size = new System.Drawing.Size(69, 17);
            this.romanNumeralLabel.TabIndex = 5;
            // 
            // arabicNumberTextBox
            // 
            this.arabicNumberTextBox.Location = new System.Drawing.Point(168, 28);
            this.arabicNumberTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.arabicNumberTextBox.Name = "arabicNumberTextBox";
            this.arabicNumberTextBox.Size = new System.Drawing.Size(68, 20);
            this.arabicNumberTextBox.TabIndex = 6;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(412, 314);
            this.Controls.Add(this.arabicNumberTextBox);
            this.Controls.Add(this.romanNumeralLabel);
            this.Controls.Add(this.romanLabel);
            this.Controls.Add(this.arabicLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.convertButton);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form1";
            this.Text = "Roman Numeral Converter";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button convertButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label arabicLabel;
        private System.Windows.Forms.Label romanLabel;
        private System.Windows.Forms.Label romanNumeralLabel;
        private System.Windows.Forms.TextBox arabicNumberTextBox;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}

