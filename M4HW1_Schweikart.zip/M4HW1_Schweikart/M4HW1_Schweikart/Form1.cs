﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/**
* 03/20/18
* CSC 153
* Brian Schweikart
* Population
*/

namespace M4HW1_Schweikart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            // set variables
            int organisms = 0;
            int increase = 0;
            int days = 0;
            int count = 1;
            double population = 0;

            // Check for data
            if (!string.IsNullOrEmpty(organismsTextBox.Text) && !string.IsNullOrEmpty(increaseTextBox.Text) && !string.IsNullOrEmpty(daysTextBox.Text))
            {
                // Retrive user input and convert to int
                organisms = Convert.ToInt32(organismsTextBox.Text);
                increase = Convert.ToInt32(increaseTextBox.Text);
                days = Convert.ToInt32(daysTextBox.Text);

                // Set the starting population
                population = organisms;

                // Display the first two lines
                populationListBox.Items.Add("Day " + " Approximate Population");
                populationListBox.Items.Add("----------------------------------");

                // Start loop
                while (count <= days)
                {
                    // add population to listbox
                    populationListBox.Items.Add("Day " + count.ToString() + "Population " + population.ToString());

                    // Calculate the increase
                    population = population + (population * increase / 100);

                    // set count value
                    count++;
                }
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the form
            organismsTextBox.Text = "";
            increaseTextBox.Text = "";
            daysTextBox.Text = "";
            populationListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }
    }
}
